package cs.dit;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class MemberDAO {

    // Connection 객체를 가져오기
    private Connection getConnection() throws Exception {
        Connection con = null;
        // 커넥션 풀로 DB와 연동
        Context initCtx = new InitialContext();
        Context ctx = (Context) initCtx.lookup("java:comp/env");
        DataSource ds = (DataSource) ctx.lookup("jdbc/jskim");
        con = ds.getConnection();
        return con;
    }

    // 전송된 데이터를 데이터베이스에 입력
    public void insert(MemberDTO dto) {
        // SQL 실행 준비
        String sql = "INSERT INTO login(id, name, pwd) VALUES (?, ?, ?)";
        
        Connection con = null;
        try {
            con = getConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, dto.getId());
            pstmt.setString(2, dto.getName());
            pstmt.setString(3, dto.getPwd());
            // SQL 실행
            pstmt.executeUpdate();
            // 자원 해제
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
