USE jspdb;

CREATE TABLE board (
    title VARCHAR(100),
    content VARCHAR(500),
    writer VARCHAR(50),
    regdate DATE
);

INSERT INTO board VALUES ('안녕', '반가워요', '홍길동', NOW());

SELECT * FROM board;
