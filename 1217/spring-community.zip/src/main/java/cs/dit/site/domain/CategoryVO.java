package cs.dit.site.domain;

import lombok.Data;

@Data
public class CategoryVO {
	
	private Long cano;
	private String title;

}
