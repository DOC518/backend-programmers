package cs.dit.site.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cs.dit.site.domain.CommentVO;
import cs.dit.site.service.CommentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@RequestMapping("/comment/*")
@Slf4j
public class CommentController {

    private final CommentService service;

    // 댓글 목록 조회
    @GetMapping("/list")
    public Map<String, Object> list(@RequestParam("bno") Long bno) {
        log.info("Fetching comment list...");
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("list", service.getList(bno)); // 댓글 목록 데이터 전달
        return response;
    }

    // 댓글 등록
    @PostMapping("/register")
    public Map<String, Object> register(@RequestBody CommentVO comment) {
        log.info("Registering comment: " + comment);

        Map<String, Object> response = new HashMap<>();
        int count = service.register(comment);

        response.put("status", count == 1 ? "success" : "error");
        response.put("message", count == 1 ? "댓글이 등록 되었습니다." : "댓글등록을 실패하였습니다.");

        return response;
    }

    // 댓글 삭제
    @PostMapping("/remove")
    public Map<String, Object> remove(@RequestBody CommentVO comment) {
        log.info("Removing comment with ID: " + comment.getCno());

        Map<String, Object> response = new HashMap<>();
        int count = service.remove(comment.getCno());

        response.put("status", count == 1 ? "success" : "error");
        response.put("message", count == 1 ? "댓글이 삭제 되었습니다." : "댓글삭제가 실패하였습니다.");

        return response;
    }
}
