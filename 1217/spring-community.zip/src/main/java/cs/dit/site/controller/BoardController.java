package cs.dit.site.controller;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import cs.dit.site.domain.BoardVO;
import cs.dit.site.domain.Criteria;
import cs.dit.site.domain.PageDTO;
import cs.dit.site.service.BoardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@RequestMapping("/board/*")
@Slf4j
public class BoardController {

    private final BoardService service;

    // 프로퍼티 파일의 uploadPath 값을 읽어옴
    @Value("${file.uploadPath}")
    private String uploadPath;

    //게시판 목록화면 이동
    @GetMapping("/list")
    public void list(Criteria cri, Model model) {

        log.info("list : " + cri);
        int total = service.getTotal(cri.getCano());
        model.addAttribute("list", service.getList(cri));
        model.addAttribute("pageMaker", new PageDTO(cri, total));
    }

    //게시판 상세 및 수정 페이지 접근
    @GetMapping({ "/get", "/modify" })
    public void get(@RequestParam("bno") Long bno, @ModelAttribute("cri") Criteria cri, Model model) {
        model.addAttribute("board", service.get(bno));
    }

    @GetMapping("/register")
    public String registerGET(HttpSession session) {
        // 미로그인시 로그인페이지로 강제이동
        String id = (String) session.getAttribute("id");
        if (id == null) {
            return "redirect:/login/login";
        }
        return "/board/register";
    }

    //게시판 등록 및 파일 업로드
    @PostMapping("/register")
    public String register(BoardVO board, @RequestParam("imgFile") MultipartFile imgFile, HttpSession session,
            RedirectAttributes rttr) {

        log.info("register : " + board);

        // 미로그인시 로그인페이지로 강제이동
        String id = (String) session.getAttribute("id");
        if (id == null) {
            return "redirect:/login/login";
        }

        try {

            log.info("파일 업로드 경로 uploadPath >>>>>>>>>>> : " + uploadPath);

            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs(); // 디렉토리가 없으면 생성
            }

            // 파일 처리
            if (!imgFile.isEmpty()) {
                String originalFileName = imgFile.getOriginalFilename();
                String extension = originalFileName != null
                        ? originalFileName.substring(originalFileName.lastIndexOf(".") + 1)
                        : "";
                String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
                String newFileName = timestamp + "_" + UUID.randomUUID() + "." + extension;
                File storeFile = new File(uploadPath, newFileName);

                imgFile.transferTo(storeFile); // 파일 저장
                board.setImgPath(newFileName); // 파일 경로를 VO에 설정
            }

            // 데이터 저장
            int count = service.register(board);
            if (count == 1) {
                rttr.addFlashAttribute("result", "registered");
            } else {
                rttr.addFlashAttribute("result", "failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
            rttr.addFlashAttribute("result", "error");
        }

        return "redirect:/board/list?cano=" + board.getCano();
    }

    // 게시글 수정 및 파일 업로드
    @PostMapping("/modify")
    public String modify(BoardVO board, @RequestParam(value = "imgFile", required = false) MultipartFile imgFile,
            @RequestParam(value = "originImgPath", required = false) String originImgPath,
            @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {

        log.info("modify : " + board);

        try {

            log.info("파일 업로드 경로 uploadPath >>>>>>>>>>> : " + uploadPath);

            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs(); // 디렉토리가 없으면 생성
            }

            // 파일 처리
            if (imgFile != null && !imgFile.isEmpty()) {
                String originalFileName = imgFile.getOriginalFilename();
                String extension = originalFileName != null
                        ? originalFileName.substring(originalFileName.lastIndexOf(".") + 1)
                        : "";
                String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
                String newFileName = timestamp + "_" + UUID.randomUUID() + "." + extension;
                File storeFile = new File(uploadPath, newFileName);
                imgFile.transferTo(storeFile); // 파일 저장
                board.setImgPath(newFileName); // 새 이미지 경로 설정
            } else {
                // 파일이 없으면 기존 이미지 경로 유지
                board.setImgPath(originImgPath);
            }

            // 데이터 수정
            int count = service.modify(board);
            if (count == 1) {
                rttr.addFlashAttribute("result", "modified");
            } else {
                rttr.addFlashAttribute("result", "failed");
            }

        } catch (Exception e) {
            log.error("File upload or modification error: ", e);
            rttr.addFlashAttribute("result", "error");
        }

        // 페이징 정보 유지
        rttr.addAttribute("pageNum", cri.getPageNum());
        rttr.addAttribute("amount", cri.getAmount());

        return "redirect:/board/list?cano=" + board.getCano();
    }

    @PostMapping("/remove")
    public String remove(@RequestParam("bno") Long bno, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
        log.info("remove : " + bno);

        int count = service.remove(bno);

        if (count == 1) {
            rttr.addFlashAttribute("result", "removed");
        }

        rttr.addAttribute("pageNum", cri.getPageNum());
        rttr.addAttribute("amount", cri.getAmount());

        return "redirect:/board/list";
    }

}
