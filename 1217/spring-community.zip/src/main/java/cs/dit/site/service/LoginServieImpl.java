package cs.dit.site.service;

import org.springframework.stereotype.Service;

import cs.dit.site.domain.LoginVO;
import cs.dit.site.mapper.LoginMapper;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor  //final로 객체주입(DI)
public class LoginServieImpl implements LoginService{

	private final LoginMapper mapper;

	@Override
	public LoginVO get(LoginVO login) {
		return mapper.read(login);
	}

	@Override
	public int register(LoginVO board) {

		return mapper.insert(board);
	}
}
