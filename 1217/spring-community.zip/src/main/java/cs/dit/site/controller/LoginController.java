package cs.dit.site.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import cs.dit.site.domain.LoginVO;
import cs.dit.site.service.LoginService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@RequestMapping("/login/*")
@Slf4j
public class LoginController {

    private final LoginService service;

    @GetMapping("/login")
    public void loginGET() {
        log.info("로그인페이지 이동 하기");
    }

    // 페이지 이동
    @GetMapping("/join")
    public void joinGET() {
        log.info("가입페이지 이동 하기");
    }

    // 로그인
    @PostMapping("/loginChk")
    public void login(HttpServletRequest request, HttpServletResponse response, LoginVO login)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String javaScriptCode = "";
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        LoginVO loginInfo = service.get(login);

        if (loginInfo == null) {
            // JavaScript 코드 생성
            javaScriptCode = "<script type=\"text/javascript\">alert('회원정보가 없습니다.'); window.location.href = '/login/login';</script>";
        } else {
            // 로그인 성공후 서버세션에 학번넣기
            session.setAttribute("uno", loginInfo.getUno());
            session.setAttribute("id", loginInfo.getId());
            session.setAttribute("name", loginInfo.getName());
            // JavaScript 코드 생성
            javaScriptCode = "<script type=\"text/javascript\">alert('로그인을 하였습니다.'); window.location.href = '/';</script>";
        }

        // JavaScript 코드를 클라이언트로 출력
        response.getWriter().write(javaScriptCode);
    }

    // 회원가입
    @PostMapping("/join")
    public void join(HttpServletResponse response, LoginVO login, RedirectAttributes rttr)
            throws ServletException, IOException {

        String javaScriptCode = "";
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        if (service.register(login) > 0) {
            // JavaScript 코드 생성
            javaScriptCode = "<script type=\"text/javascript\">alert('회원가입을 하였습니다.'); window.location.href = '/login/login';</script>";
        } else {
            javaScriptCode = "<script type=\"text/javascript\">alert('회원가입을 실패하였습니다.'); window.location.href = '/login/join';</script>";
        }

        // JavaScript 코드를 클라이언트로 출력
        response.getWriter().write(javaScriptCode);
    }

    /* 로그아웃 */
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

}
