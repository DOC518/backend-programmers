package cs.dit.site.mapper;

import cs.dit.site.domain.LoginVO;

public interface LoginMapper {

	public int insert(LoginVO loginVO);

	public LoginVO read(LoginVO login);
}

