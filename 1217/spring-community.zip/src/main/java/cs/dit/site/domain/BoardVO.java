package cs.dit.site.domain;

import java.util.Date;

import lombok.Data;

@Data
public class BoardVO {

	private Long bno,cano;
	private String title, content, writer, imgPath;
	private Date regDate, updateDate;

}
