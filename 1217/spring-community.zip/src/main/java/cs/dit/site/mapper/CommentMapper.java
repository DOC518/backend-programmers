package cs.dit.site.mapper;

import java.util.List;

import cs.dit.site.domain.CommentVO;

public interface CommentMapper {

	public List<CommentVO> getList(Long bno);

	public int insert(CommentVO comment);

	public int delete(Long cno);
}

