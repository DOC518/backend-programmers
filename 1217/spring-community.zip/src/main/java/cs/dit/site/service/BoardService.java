package cs.dit.site.service;

import java.util.List;

import cs.dit.site.domain.BoardVO;
import cs.dit.site.domain.Criteria;

public interface BoardService {

	public List<BoardVO> getList(Integer cano);

	public List<BoardVO> getList(Criteria cri);

	public BoardVO get(Long bno);

	public int register(BoardVO board);

	public int modify(BoardVO board);

	public int remove(Long bno);

	public int getTotal(int cano);

}
