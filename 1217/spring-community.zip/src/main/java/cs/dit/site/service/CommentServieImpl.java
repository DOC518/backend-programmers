package cs.dit.site.service;

import java.util.List;

import org.springframework.stereotype.Service;

import cs.dit.site.domain.CommentVO;
import cs.dit.site.mapper.CommentMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor  //final로 객체주입(DI)
@Slf4j
public class CommentServieImpl implements CommentService{

	private final CommentMapper mapper;

	@Override
	public List<CommentVO> getList(Long bno) {
		return mapper.getList(bno);
	}

	@Override
	public int register(CommentVO comment) {

		return mapper.insert(comment);
	}

	@Override
	public int remove(Long cno) {

		return mapper.delete(cno);
	}

}
