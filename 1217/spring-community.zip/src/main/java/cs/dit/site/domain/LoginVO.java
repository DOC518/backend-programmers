package cs.dit.site.domain;

import lombok.Data;

@Data
public class LoginVO {

	private Long uno;
	private String id, name, pass;

}
