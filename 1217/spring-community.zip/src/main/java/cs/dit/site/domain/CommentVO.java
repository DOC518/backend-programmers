package cs.dit.site.domain;

import lombok.Data;

@Data
public class CommentVO {

	private Long cno, bno;
	private String content, writer;
	private String regDate;

}
