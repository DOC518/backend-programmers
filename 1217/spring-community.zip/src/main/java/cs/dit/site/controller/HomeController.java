package cs.dit.site.controller;

import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cs.dit.site.service.BoardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
public class HomeController {

    private final BoardService service;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String home(Locale locale, Model model) {
        log.info(">>>>>>>>>>>>>>>>>>>> 메인 진입 <<<<<<<<<<<<<<<<<<<<<<<<<");
        // 자유
        model.addAttribute("list1", service.getList(1));
        // 정치
        model.addAttribute("list2", service.getList(2));
        // 쇼핑
        model.addAttribute("list3", service.getList(3));
        // 취미
        model.addAttribute("list4", service.getList(4));
        // 패션
        model.addAttribute("list5", service.getList(5));
        return "home";
    }

}
