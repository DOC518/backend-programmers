package cs.dit.site.service;

import java.util.List;

import cs.dit.site.domain.CommentVO;

public interface CommentService {

	public List<CommentVO> getList(Long bno);

	public int register(CommentVO comment);

	public int remove(Long cno);

}
