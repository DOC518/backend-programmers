package cs.dit.site.service;

import java.util.List;

import org.springframework.stereotype.Service;

import cs.dit.site.domain.BoardVO;
import cs.dit.site.domain.Criteria;
import cs.dit.site.mapper.BoardMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class BoardServieImpl implements BoardService{

	private final BoardMapper mapper;

	@Override
	public List<BoardVO> getList(Integer cano) {

		return mapper.getList(cano);
	}


	@Override
	public List<BoardVO> getList(Criteria cri) {

		log.info("get List with Criteria : " + cri);

		return mapper.getListPage(cri);
	}

	@Override
	public BoardVO get(Long bno) {
		return mapper.read(bno);
	}

	@Override
	public int register(BoardVO board) {

		return mapper.insert(board);
	}

	@Override
	public int modify(BoardVO board) {

		return mapper.update(board);
	}

	@Override
	public int remove(Long bno) {

		return mapper.delete(bno);
	}

	@Override
	public int getTotal(int cano) {

		return mapper.getTotal(cano);
	}

}
