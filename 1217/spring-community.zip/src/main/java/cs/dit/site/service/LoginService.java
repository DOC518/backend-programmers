package cs.dit.site.service;

import cs.dit.site.domain.LoginVO;

public interface LoginService {

	public LoginVO get(LoginVO login);

	public int register(LoginVO login);

}
