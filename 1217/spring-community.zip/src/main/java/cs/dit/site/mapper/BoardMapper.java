package cs.dit.site.mapper;

import java.util.List;

import cs.dit.site.domain.BoardVO;
import cs.dit.site.domain.CategoryVO;
import cs.dit.site.domain.Criteria;

public interface BoardMapper {

	public List<BoardVO> getList(Integer cano);

	public List<BoardVO> getListPage(Criteria cri);

	public int insert(BoardVO board);

	public BoardVO read(Long bno);

	public int delete(Long bno);

	public int update(BoardVO board);

	public int getTotal(int cano);

	public List<CategoryVO> getCategoryList();
}

