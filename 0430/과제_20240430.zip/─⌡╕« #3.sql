USE jspdb;

CREATE TABLE login(
	id VARCHAR(20),
	name VARCHAR(50),
	pwd VARCHAR(20)
);