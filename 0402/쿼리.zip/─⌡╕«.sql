-- 1. 데이터베이스 생성
CREATE DATABASE MEMBER;

-- 2. 사용자 생성
CREATE USER jsp@localhost IDENTIFIED BY '1111';


-- 3. 사용자에게 권행울 부여
SELECT HOST, USER FROM mysql.us

-- 3. 사용자에게 해당 DB에 대한 권행울 부여
GRANT ALL PRIVILEGES ON jspdb.* TO jsp@localhost WITH GRANT OPTION; 
FLUSH PRIVILEGES;
USE mysql;