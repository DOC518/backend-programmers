package cs.dit;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class MemberDAO {

    // Connection 객체를 가져오기
    private Connection getConnection() throws Exception {
        // 커넥션 풀로 DB와 연동
        Context initCtx = new InitialContext();
        Context ctx = (Context) initCtx.lookup("java:comp/env");
        DataSource ds = (DataSource) ctx.lookup("jdbc/juyoung");
        return ds.getConnection();
    }

    // 전송된 데이터를 데이터베이스에 입력
    public void insert(MemberDTO dto) {
        // SQL 실행 준비
        String sql = "INSERT INTO login(id, name, pwd) VALUES (?, ?, ?)";

        try (Connection con = getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, dto.getId());
            pstmt.setString(2, dto.getName());
            pstmt.setString(3, dto.getPwd());
            // SQL 실행
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 데이터베이스에 있는 데이터를 가져오기
    public ArrayList<MemberDTO> list() {
        ArrayList<MemberDTO> dtos = new ArrayList<>();
        String sql = "SELECT id, name, pwd FROM login";

        // 커넥션 가져오기
        try (Connection con = getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql);) {
            // SQL 문 실행하기
            while (rs.next()) {
                MemberDTO dto = new MemberDTO();
                dto.setId(rs.getString("id"));
                dto.setName(rs.getString("name"));
                dto.setPwd(rs.getString("pwd"));
                dtos.add(dto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 결과리스트를 리턴하기
        return dtos;
    }

    // 특정 ID의 데이터를 가져오기
    public MemberDTO selectOne(String id) {
        MemberDTO dto = null;
        String sql = "SELECT * FROM login WHERE id = ?";

        // 1. 커넥션 가져오기
        try (Connection con = getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, id);
            
            // 2. SQL 문 실행하기
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    dto = new MemberDTO();
                    dto.setId(rs.getString("id"));
                    dto.setName(rs.getString("name"));
                    dto.setPwd(rs.getString("pwd"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 3. 결과 리턴하기
        return dto;
    }
    //Login 데이터를 변경하는 메소드 , updatePro
    public void update(MemberDTO dto) {
    	String sql = "UPDATE login SET name = ?, pwd = ? WHERE id = ?";
    	
    	try(Connection con = getConnection();
                PreparedStatement pstmt = con.prepareStatement(sql)) {
               pstmt.setString(1, dto.getName());
               pstmt.setString(2, dto.getPwd());
               pstmt.setString(3, dto.getId());

               // SQL 실행
               pstmt.executeUpdate();
           } catch (Exception e) {
               e.printStackTrace();
           }
   }
    
    //Login 데이터 삭제 메소드 , delete
    public void delete(String id) {
        // SQL 실행 준비
        String sql = "DELETE FROM login WHERE id = ?";

        try (Connection con = getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            // SQL 파라미터 설정
            pstmt.setString(1, id);

            // SQL 실행
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
