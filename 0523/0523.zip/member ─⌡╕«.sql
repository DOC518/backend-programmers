SHOW DATABASES;

USE jspdb;

# member table 생성
CREATE TABLE MEMBER(
	id VARCHAR(5),
	pwd VARCHAR(10),
	addr VARCHAR(100)
);

INSERT INTO MEMBER(id, pwd, addr)
VALUES('gildo', '1111', '부산');
INSERT INTO MEMBER(id, pwd, addr)
VALUES('lee', '1111', '서울');
INSERT INTO MEMBER(id, pwd, addr)
VALUES('kim', '1111', '부산');
INSERT INTO MEMBER(id, pwd, addr)
VALUES('yun', '1111', '광주');
INSERT INTO MEMBER(id, pwd, addr)
VALUES('lim', '1111', '울산');

-- 테이블 데이터 조회
SELECT * FROM MEMBER;

SELECT * FROM MEMBER ORDER BY addr;

-- 값 변경
UPDATE MEMBER
set addr='춘천'
WHERE id='kim';

길동의 주소를 춘천으로 바꾸고 비번도 0000으로
UPDATE MEMBER
set addr='춘천', pwd='0000'
WHERE id='gildo';

-- 데이터 삭제
DELETE FROM MEMBER WHERE num = 1 AND id = 'lee';

CREATE TABLE MEMBER2(
	ID INT PRIMARY KEY,
	PWD VARCHAR(50),
	NAME VARCHAR(50),
	GENDER CHAR(2),
	PHONE CHAR(13),
	REGDATE DATE
);
COMMITjspdb